// Backend entry point
