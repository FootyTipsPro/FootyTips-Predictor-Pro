# FootyTips Predicter Pro

Full-stack football tipping app with machine learning predictions.
